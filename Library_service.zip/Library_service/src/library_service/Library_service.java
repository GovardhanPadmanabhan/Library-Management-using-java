/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library_service;

/**
 *
 * @author Govardhan
 */

import java.io.FileWriter;
import java.io.FileReader;

public class Library_service {

    /**
     * @param args the command line arguments
     */

    
    public static void main(String[] args) {
        new main_page().setVisible(true);
        //this.setVisible(false);
    }
    
}
