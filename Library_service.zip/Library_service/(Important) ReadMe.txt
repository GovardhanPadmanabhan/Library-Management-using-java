Thank you for downloading my project _/\_

This project was developed by Govardhan Padmanabhan.
In GitHub.com, i am unable to upload the entire project, as it limits to only 100 files. If you want the entire project, or it doesn't run, send a request to the specified mail id.
Please keep in mind that this project was developed for the first semester project using java. If it not up to your standards, please feel free to make changes,
and if it is better, please do a pull request, but do not hold the author liable for any errors or problems.



NOTE:

For this project to work, you need a "D:/" drive. if you do not have one, change the file locations in each JFrame before running. Also, create the folders "Members",  "Librarians", 
"Categories", and "Books" in the same directory before running them.

For the Head Librarian login page, "admin" is the username, and "admin123" is the password.

For Librarians, you must the unique pin (can be viewd in the "View Librarians" class, or in the "librarians.txt" file) created for each librarian to clock in and clock out.
While adding books, remeber that the book id are case sensitive, i.e., it will treat "A@1" and "a@1" as two different book id.

For members, you can renew your membership after 365 days.
You can only borrow one book at a time.
You must return your book within 14 days, otherwise it becomes "Overdue".
If for three times you have "overdue" status, you will be fined, and will not be allowed to borrow books, unless the fine is removed by a librarian.




If you still have any queries about the project, please send a mail to "govardhanpadmanabhan99@gmail.com"



